document.addEventListener('DOMContentLoaded', () => {
    const orderTypeButtons = document.querySelectorAll('.order-type-btn');
    const menuTabButtons = document.querySelectorAll('.menu-tab-btn');
    const paymentButtons = document.querySelectorAll('.payment-btn');
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    const cartItemsContainer = document.getElementById('cart-items');
    const subtotalElement = document.getElementById('subtotal');
    const taxElement = document.getElementById('tax');
    const serviceFeeElement = document.getElementById('service-fee');
    const totalElement = document.getElementById('total');
    const payButton = document.getElementById('payBtn');
    const genTokenButton = document.getElementById('genToken');
    const tokenContainer = document.getElementById('token-container');
    const tokenElement = document.getElementById('token');
    const menuItemsContainer = document.getElementById('menu-items-container');
    const allMenuItems = Array.from(menuItemsContainer.children);
    //Get total Input Element
    let cart = [];
    const serviceFee = 0.50;
    const taxRate = 0.08;
    let totalAmount = 0;
  function updateCartItem(itemId, quantity) {
    const existingItemIndex = cart.findIndex(item => item.id === itemId);
        //Find Index
    if (existingItemIndex !== -1) {
      cart[existingItemIndex].quantity = quantity; //Override
        //Now you can make sure to override current value
      updateCartDisplay();
    }
  }
    // Helper function to format currency
    function formatCurrency(amount) {
        return '₹' + amount.toFixed(2);
    }

    // Function to generate a token number
    function generateToken() {
        const token = Math.floor(Math.random() * 10000);  // Generate a random 4-digit number
        return token;
    }

    // Function to update the cart display
    function updateCartDisplay() {
        cartItemsContainer.innerHTML = '';
        let subtotal = 0;

        if (cart.length === 0) {
            cartItemsContainer.innerHTML = '<p class="text-gray-500">Your cart is empty.</p>';
        } else {
            cart.forEach((item, index) => {
                const cartItemElement = document.createElement('div');
                cartItemElement.classList.add('flex', 'justify-between', 'items-center', 'py-1', 'border-b', 'border-gray-200');
                cartItemElement.innerHTML = `
                    <span class="text-gray-700 font-semibold">${item.name}</span>
                    <div class="flex items-center">
                        <button class="quantity-btn decrement-btn text-gray-600 hover:text-gray-800 px-2" data-item-id="${item.id}">-</button>
                        <span class="text-gray-700">${item.quantity}</span>
                        <button class="quantity-btn increment-btn text-gray-600 hover:text-gray-800 px-2" data-item-id="${item.id}">+</button>
                        <span class="text-gray-700 ml-2">${formatCurrency(item.price * item.quantity)}</span>
                        <button class="remove-item ml-2 text-red-500 hover:text-red-700 focus:outline-none" data-index="${index}">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                `;
                cartItemsContainer.appendChild(cartItemElement);
                subtotal += item.price * item.quantity;
            });
        }

        const tax = subtotal * taxRate;
        const total = subtotal + tax + serviceFee;
        totalAmount = total;

        subtotalElement.textContent = formatCurrency(subtotal);
        taxElement.textContent = formatCurrency(tax);
        serviceFeeElement.textContent = formatCurrency(serviceFee);
        totalElement.textContent = formatCurrency(total);
    }

    // Add item to cart
    addToCartButtons.forEach(button => {
        button.addEventListener('click', () => {
            const menuItem = button.closest('.menu-item');
            const itemId = menuItem.dataset.id;
            const itemName = menuItem.dataset.name;
            const itemPrice = parseFloat(menuItem.dataset.price);

            const existingItem = cart.find(item => item.id === itemId);

            if (existingItem) {
                existingItem.quantity++;
            } else {
                cart.push({
                    id: itemId,
                    name: itemName,
                    price: itemPrice,
                    quantity: 1
                });
            }

            updateCartDisplay();
        });
    });
   //New Code
      cartItemsContainer.addEventListener('click', (event) => {
          //Decrement Item
        if (event.target.classList.contains('decrement-btn')) {
          const itemId = event.target.dataset.itemId;
          const existingItemIndex = cart.findIndex(item => item.id === itemId);
           if (existingItemIndex !== -1) {
                if (cart[existingItemIndex].quantity > 1) {
                  cart[existingItemIndex].quantity--;
                   updateCartDisplay();
                } else {
                   // If quantity is 1, remove the item from the cart
                   cart.splice(existingItemIndex, 1);
                    updateCartDisplay();
                }
            }
        }
        //Increment Item
        if (event.target.classList.contains('increment-btn')) {
          const itemId = event.target.dataset.itemId;
            const existingItemIndex = cart.findIndex(item => item.id === itemId);
          if(existingItemIndex !== -1){
               cart[existingItemIndex].quantity++;
               updateCartDisplay();
          }
        }
        // Remove item from cart
        if (event.target.classList.contains('remove-item') || event.target.closest('.remove-item')) {
            const index = event.target.dataset.index || event.target.closest('.remove-item').dataset.index;
            cart.splice(index, 1);
            updateCartDisplay();
        }
    });
    // Function to handle button activation (for order type, menu tabs, payment)
    function activateButton(buttons, event) {
        buttons.forEach(button => button.classList.remove('active', 'bg-red-500', 'text-white', 'bg-gray-200', 'text-gray-700'));
        event.target.classList.add('active', 'bg-red-500', 'text-white');
        buttons.forEach(button => {
            if (button !== event.target) {
                button.classList.add('bg-gray-200', 'text-gray-700');
            }
        });
    }

    // Order Type Buttons
    orderTypeButtons.forEach(button => {
        button.addEventListener('click', (event) => {
            activateButton(orderTypeButtons, event);
            // Add logic here to handle different order types (dine-in, takeaway)
            const orderType = event.target.dataset.type;
            console.log(`Order type selected: ${orderType}`);
        });
    });

    // Menu Tab Buttons
    menuTabButtons.forEach(button => {
        button.addEventListener('click', (event) => {
            activateButton(menuTabButtons, event);
            const menuTab = event.target.dataset.tab;
            console.log(`Menu tab selected: ${menuTab}`);

            // Filter the menu items based on the selected tab
            filterMenuItems(menuTab);
        });
    });

    // Payment Buttons
    paymentButtons.forEach(button => {
        button.addEventListener('click', (event) => {
            activateButton(paymentButtons, event);
            // Add logic here to handle different payment methods
            const paymentMethod = event.target.dataset.payment;
            console.log(`Payment method selected: ${paymentMethod}`);
        });
    });

    // Filter Menu Items Function
    function filterMenuItems(category) {
        menuItemsContainer.innerHTML = '';  // Clear existing items
        allMenuItems.forEach(item => {
            if (category === 'popular' || item.dataset.category === category) {
                menuItemsContainer.appendChild(item); // Add the item to the container
            }
        });
    }
    // The main part of our rewrite: The Razorpay integration
    //Payment Razorpay
    payButton.onclick = function() {
        var options = {
            "key": "rzp_test_1DP5mmOlF5G5ag", // Free Test Key (Replace with Live Key for production)
            "amount": totalAmount * 100, // Amount in paise (multiply by 100)
            "currency": "INR",
            "name": "Test Business",
            "description": "Test Payment",
            "handler": function(response) {
                alert("✅ Payment Successful! Payment ID: " + response.razorpay_payment_id);
            },
            "prefill": {
                "name": "Test User",
                "email": "test@example.com",
                "contact": "9999999999"
            },
            "theme": { "color": "#ff9800" }
        };
        var rzp = new Razorpay(options);
        rzp.open();
    };
// Get Token Button
  genTokenButton.onclick = function () {
        const token = generateToken();
       tokenElement.textContent = token;
   };

    // Initial cart display and initial filter
    updateCartDisplay();
    filterMenuItems('popular'); // Show popular items by default
});