from flask import Flask, render_template, request, redirect, url_for
import os
import secrets #Import the secrets

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'your_default_secret_key')

#Dummy Data for Menus and categories for filter
menu_items = [
    {'id': 'chicken1', 'price': 190.99, 'name': 'chicken tandoori', 'category': 'chicken', 'image': 'chicken.jpg'},
    {'id': 'fries1', 'price': 80.49, 'name': ' Peri Peri fries', 'category': 'sides', 'image': 'fries.jpg'},
    {'id': 'burger1', 'price': 170.99, 'name': 'Double Burger', 'category': 'burgers', 'image': 'burger.jpg'},
    {'id': 'sandwich1', 'price': 60.49, 'name': 'Chicken Sandwich', 'category': 'chicken', 'image': 'sandwich.jpg'},
     {'id': 'beverages1', 'price': 100.99, 'name': 'beverages', 'category': 'beverages', 'image': 'beverages.jpg'},
    {'id': 'desserts1', 'price': 250.49, 'name': 'desserts', 'category': 'desserts', 'image': 'desserts.jpg'}
]

# Route for the main page
@app.route('/')
def index():
    return render_template('index.html', menu_items=menu_items)

# Route for the login/register page
@app.route('/login')
def login():
    return render_template('login.html')

#Route to redirect to index after login
@app.route('/login_success', methods=['POST'])
def login_success():
    # Replace by proper implementation
    return redirect(url_for('index'))

#Route to redirect to index after register
@app.route('/register_success', methods=['POST'])
def register_success():
    # Replace by proper implementation
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)